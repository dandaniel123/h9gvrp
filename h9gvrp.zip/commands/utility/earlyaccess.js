import { SlashCommandBuilder, EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle, ComponentType } from 'discord.js';

export default {
    data: new SlashCommandBuilder()
        .setName('ea')
        .setDescription('Sends the early access embed.')
        .addStringOption(option =>
            option.setName('session-link')
                .setDescription('Link for the session so that EA people can join.')
                .setRequired(true)),
    async execute(interaction) {
        const sessionLink = interaction.options.getString('session-link');

        const embed = new EmbedBuilder()
            .setTitle('H9GVRP | Early Access')
            .setDescription(`Early Access is now Released! Nitro Boosters, members of the Emergency Services, and Content Creators can join the session by clicking the button below.\n\nPlease remember, sharing the session link with others is strictly prohibited and may lead to penalties. We appreciate your cooperation in keeping our community secure and fair for everyone.\n`)
            .setColor(`#89CFF0`)
            .setFooter({
                text: 'H9GVRP',
                iconURL: 'https://cdn.discordapp.com/icons/1231665533653352500/34384aaf6d1081a7c44f572d0c46cb67.png?size=4096'
            });

        const button = new ButtonBuilder()
            .setLabel('Early Access')
            .setStyle(ButtonStyle.Secondary)
            .setCustomId('ea');

        const row = new ActionRowBuilder()
            .addComponents(button);

        // Send the embed message with the button to the channel
        await interaction.channel.send({ content: '<@&1253043896481484880>, <@&1250603750033199154>', embeds: [embed], components: [row] });

        // Send an ephemeral confirmation message
        await interaction.reply({ content: 'Command Sent Below.', ephemeral: true });

        // Create a collector to handle the button interaction
        const filter = i => i.customId === 'ea';
        const collector = interaction.channel.createMessageComponentCollector({ filter, componentType: ComponentType.BUTTON, time: 9999999 });

        collector.on('collect', async i => {
            try {
                if (i.member.roles.cache.has('1253043896481484880') || i.member.roles.cache.has('1250786185677242463') || i.member.roles.cache.has('1250603750033199154'))   {
                    await i.reply({ content: `**Link:** ${sessionLink}`, ephemeral: true });
                } else {
                    await i.reply({ content: `Nuh uh, you do not have the early access role.`, ephemeral: true });
                }
            } catch (error) {
                console.error('Error responding to interaction:', error);
            }
        });

        collector.on('end', collected => {
            console.log(`Collected ${collected.size} interactions.`);
        });
    },
};
