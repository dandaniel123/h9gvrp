import { SlashCommandBuilder, EmbedBuilder } from 'discord.js';

export default {
    data: new SlashCommandBuilder()
        .setName('cohost')
        .setDescription('This tells the server you are cohosting the session'),
    async execute(interaction) {
        const user = interaction.user;

        const embed = new EmbedBuilder()
            .setTitle('H9GVRP | Cohost')
            .setDescription(` ${user}! will be cohosting the session being hosted.`)
            .setColor(`#89CFF0`)
            .setFooter({
                text: 'H9GVRP',
                iconURL: 'https://cdn.discordapp.com/icons/1231665533653352500/34384aaf6d1081a7c44f572d0c46cb67.png?size=4096'
            });

        // Send the embed message to the channel
        const message = await interaction.channel.send({ content: `${user}`, embeds: [embed] });

        // Send an ephemeral confirmation message
        await interaction.reply({ content: 'Command Sent Below.', ephemeral: true });
    },
};