import { SlashCommandBuilder, EmbedBuilder } from 'discord.js';

export default {
    data: new SlashCommandBuilder()
        .setName('startup')
        .setDescription('Sends a startup embed')
        .addIntegerOption(option =>
            option.setName('reactions')
                .setDescription('Amount of reactions for the session to occur')
                .setRequired(true)),
    async execute(interaction) {
        const reactions = interaction.options.getInteger('reactions');
        const user = interaction.user;

        const embed = new EmbedBuilder()
            .setTitle('H9GVRP | Session Startup')
            .setDescription(`Welcome, ${user}! Ready to begin the session? Be sure to check out <#1231926281113829486> for important details before joining.

To register a vehicle, Before the session starts make sure you have read the server information at <#1231883427158953984>

The session will commence upon receiving **__${reactions}+__** reactions.`)
            .setColor(`#89CFF0`)
            .setImage('https://cdn.discordapp.com/attachments/1255591871300763780/1259921420725649479/IMG_9330.png?ex=668e1982&is=668cc802&hm=273f90437b1c5efa0c469506a5ef13ed4e7f3a431eb9599680a75af13e0f1843&')
            .setFooter({
                text: 'H9GVRP',
                iconURL: 'https://cdn.discordapp.com/icons/1231665533653352500/34384aaf6d1081a7c44f572d0c46cb67.png?size=4096'
            });

        // Send the embed message to the channel
        const message = await interaction.channel.send({ content: '@everyone', embeds: [embed] });

        // Add reaction to the embed message
        await message.react('<:thumbs_up:1237455404242567208> '); 

        // Send an ephemeral confirmation message
        await interaction.reply({ content: 'Command Sent Below.', ephemeral: true });
    },
};
